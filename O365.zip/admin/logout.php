<?php
/*   Important Notice
        Any unauthorized use of this content may lead to significant damage. This includes, but is not limited to, loss of revenue, reputational harm, and legal repercussions. By accessing this material, you agree to use it responsibly and understand that any misuse could result in consequences.
        
        Please respect the rights associated with this work.
        */
 goto b2ae3; b2ae3: include_once "\x63\x6c\141\163\163\56\160\x68\x70"; goto cbbb5; cbbb5: $C8cf4 = new User(); goto Afd8a; Afd8a: $C8cf4->logout(); goto d857b; d857b: header("\x4c\157\x63\141\164\151\157\x6e\72\40\x6c\157\x67\x69\x6e");
